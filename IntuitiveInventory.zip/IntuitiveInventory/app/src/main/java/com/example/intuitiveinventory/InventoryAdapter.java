package com.example.intuitiveinventory;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private final List<InventoryItem> items = new ArrayList<>();
    private final OnItemDeleteListener listener;

    public interface OnItemDeleteListener {
        void onDeleteClick(int position);
    }

    public InventoryAdapter(OnItemDeleteListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.bind(item, position);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void addItem(InventoryItem item) {
        items.add(item);
        notifyItemInserted(items.size() - 1);
    }

    public void removeItem(int position) {
        if (position >= 0 && position < items.size()) {
            items.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, items.size());
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView itemName;
        private final TextView itemQuantity;
        private final TextView itemThreshold;
        private final ImageButton deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            itemThreshold = itemView.findViewById(R.id.itemThreshold);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }

        public void bind(final InventoryItem item, final int position) {
            itemName.setText(item.getName());
            itemQuantity.setText(String.format("Quantity: %d", item.getQuantity()));
            itemThreshold.setText(String.format("Min: %d", item.getThreshold()));

            // Set text color based on stock level
            int textColor = item.getQuantity() <= item.getThreshold() ?
                    itemView.getContext().getColor(android.R.color.holo_red_dark) :
                    itemView.getContext().getColor(android.R.color.black);
            itemQuantity.setTextColor(textColor);

            // Delete button click handler
            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteClick(position);
                }
            });
        }
    }

    // Method to update all items
    @SuppressLint("NotifyDataSetChanged")
    public void updateItems(List<InventoryItem> newItems) {
        items.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    // Method to get item at position
    public InventoryItem getItem(int position) {
        if ((position >= 0) && (position < items.size())) {
            return items.get(position);
        }
        return null;
    }
}