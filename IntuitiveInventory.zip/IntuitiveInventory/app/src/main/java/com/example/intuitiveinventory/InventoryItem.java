package com.example.intuitiveinventory;

// Creates New Inventory Item
public class InventoryItem {
    private long id;
    private String name;
    private int quantity;
    private int threshold;

    public InventoryItem(long id, String name, int quantity, int threshold) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.threshold = threshold;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public int getThreshold() { return threshold; }
    public void setThreshold(int threshold) { this.threshold = threshold; }

    public boolean isLowStock() {
        return quantity <= threshold;
    }
}