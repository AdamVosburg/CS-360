package com.example.intuitiveinventory;

import static android.os.Build.*;
import static android.telephony.SmsManager.getDefault;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "inventory_notifications";
    private static final int NOTIFICATION_ID = 1;
    private static final String PREF_NAME = "InventoryPrefs";
    private static final String KEY_USER_ID = "userId";

    private RecyclerView recyclerView;
    private View emptyStateText;
    private InventoryAdapter adapter;
    private DatabaseHelper dbHelper;
    private SharedPreferences preferences;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize database and preferences
        dbHelper = new DatabaseHelper(this);
        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        userId = preferences.getLong(KEY_USER_ID, -1);

        if (userId == -1) {
            handleBackNavigation();
            return;
        }

        setupToolbar();
        createNotificationChannel();
        initializeViews();
        setupRecyclerView();
        loadInventoryItems();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        View backButton = findViewById(R.id.backButton);
        if (backButton != null) {
            backButton.setOnClickListener(v -> handleBackNavigation());
        }
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.inventoryRecyclerView);
        emptyStateText = findViewById(R.id.emptyStateText);
        FloatingActionButton addItemFab = findViewById(R.id.addItemFab);

        if (addItemFab != null) {
            addItemFab.setOnClickListener(v -> showAddItemDialog());
        }
    }

    private void setupRecyclerView() {
        adapter = new InventoryAdapter(position -> {
            InventoryItem item = adapter.getItem(position);
            if (item != null && dbHelper.deleteInventoryItem(item.getId())) {
                adapter.removeItem(position);
                updateEmptyState(adapter.getItemCount() == 0);
                Toast.makeText(InventoryActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(adapter);
    }

    private void loadInventoryItems() {
        Cursor cursor = dbHelper.getAllInventoryItems(userId);
        List<InventoryItem> items = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                int threshold = cursor.getInt(cursor.getColumnIndexOrThrow("threshold"));

                items.add(new InventoryItem(id, name, quantity, threshold));
            } while (cursor.moveToNext());

            cursor.close();
        }

        adapter.updateItems(items);
        updateEmptyState(items.isEmpty());
    }

    private void showAddItemDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_inventory, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        TextInputEditText nameInput = dialogView.findViewById(R.id.nameInput);
        TextInputEditText quantityInput = dialogView.findViewById(R.id.quantityInput);
        TextInputEditText thresholdInput = dialogView.findViewById(R.id.thresholdInput);

        AlertDialog dialog = builder.create();

        dialogView.findViewById(R.id.addButton).setOnClickListener(v -> {
            String name = nameInput.getText() != null ? nameInput.getText().toString().trim() : "";
            String quantityStr = quantityInput.getText() != null ? quantityInput.getText().toString().trim() : "";
            String thresholdStr = thresholdInput.getText() != null ? thresholdInput.getText().toString().trim() : "";

            if (validateInputs(name, quantityStr, thresholdStr)) {
                int quantity = Integer.parseInt(quantityStr);
                int threshold = Integer.parseInt(thresholdStr);

                long itemId = dbHelper.addInventoryItem(name, quantity, threshold, userId);
                if (itemId != -1) {
                    InventoryItem newItem = new InventoryItem(itemId, name, quantity, threshold);
                    adapter.addItem(newItem);
                    updateEmptyState(false);

                    if (quantity <= threshold) {
                        sendLowStockAlert(newItem);
                    }
                }
                dialog.dismiss();
            }
        });

        dialogView.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void sendLowStockAlert(InventoryItem item) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = getDefault(); // Changed this line
                String message = "Low stock alert: " + item.getName() + " is below minimum threshold";
                smsManager.sendTextMessage(null, null, message, null, null);
            } catch (Exception e) {
                showNotification(item);
            }
        } else {
            showNotification(item);
        }
    }

    private void showNotification(InventoryItem item) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Low Stock Alert")
                .setContentText(item.getName() + " is below minimum threshold")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        try {
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        } catch (SecurityException e) {
            Toast.makeText(this, "Notification permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    private void createNotificationChannel() {
        if (VERSION.SDK_INT >= VERSION_CODES.O) {
            CharSequence name = "Inventory Alerts";
            String description = "Notifications for low stock items";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private boolean validateInputs(String name, String quantityStr, String thresholdStr) {
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (quantityStr.isEmpty()) {
            Toast.makeText(this, "Please enter a quantity", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (thresholdStr.isEmpty()) {
            Toast.makeText(this, "Please enter a threshold", Toast.LENGTH_SHORT).show();
            return false;
        }
        try {
            int quantity = Integer.parseInt(quantityStr);
            int threshold = Integer.parseInt(thresholdStr);
            if (quantity < 0 || threshold < 0) {
                Toast.makeText(this, "Values must be positive numbers", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void updateEmptyState(boolean isEmpty) {
        if (emptyStateText != null && recyclerView != null) {
            emptyStateText.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
            recyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        }
    }

    private void handleBackNavigation() {
        preferences.edit().remove(KEY_USER_ID).apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        handleBackNavigation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}