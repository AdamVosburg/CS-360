package com.example.intuitiveinventory;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    // Constants for permissions and preferences
    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREF_NAME = "InventoryPrefs";
    private static final String KEY_USER_ID = "userId";

    // UI Components
    private TextInputLayout usernameLayout;
    private TextInputLayout passwordLayout;
    private TextInputEditText usernameEditText;
    private TextInputEditText passwordEditText;
    private MaterialButton loginButton;
    private MaterialButton createAccountButton;

    // Database and Preferences
    private DatabaseHelper dbHelper;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database and preferences
        dbHelper = new DatabaseHelper(this);
        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Check for existing login
        if (checkExistingLogin()) {
            return;
        }

        initializeViews();
        setupListeners();
        checkSmsPermission();
    }

    private boolean checkExistingLogin() {
        long userId = preferences.getLong(KEY_USER_ID, -1);
        if (userId != -1) {
            navigateToInventory();
            return true;
        }
        return false;
    }

    private void initializeViews() {
        // Initialize TextInputLayouts
        usernameLayout = findViewById(R.id.usernameLayout);
        passwordLayout = findViewById(R.id.passwordLayout);

        // Initialize EditTexts
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Initialize Buttons
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Initially disable login button
        loginButton.setEnabled(false);
    }

    private void setupListeners() {
        // Button click listeners
        loginButton.setOnClickListener(v -> handleLogin());
        createAccountButton.setOnClickListener(v -> handleCreateAccount());

        // Text change listener for input validation
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateInputs();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not used
            }
        };

        // Add text watchers to input fields
        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);
    }

    private void validateInputs() {
        String username = usernameEditText.getText() != null ? usernameEditText.getText().toString().trim() : "";
        String password = passwordEditText.getText() != null ? passwordEditText.getText().toString().trim() : "";
        loginButton.setEnabled(!username.isEmpty() && !password.isEmpty());
    }

    private void handleLogin() {
        // Get input values
        String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(username)) {
            usernameLayout.setError("Username is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError("Password is required");
            return;
        }

        // Clear any existing errors
        usernameLayout.setError(null);
        passwordLayout.setError(null);

        // Attempt login
        if (dbHelper.validateUser(username, password)) {
            long userId = dbHelper.getUserId(username);
            preferences.edit().putLong(KEY_USER_ID, userId).apply();
            navigateToInventory();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleCreateAccount() {
        // Get input values
        String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(username)) {
            usernameLayout.setError("Username is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError("Password is required");
            return;
        }

        // Clear any existing errors
        usernameLayout.setError(null);
        passwordLayout.setError(null);

        // Attempt to create account
        long userId = dbHelper.createUser(username, password);
        if (userId != -1) {
            preferences.edit().putLong(KEY_USER_ID, userId).apply();
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            navigateToInventory();
        } else {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Update user's SMS preference in database
                long userId = preferences.getLong(KEY_USER_ID, -1);
                if (userId != -1) {
                    dbHelper.setSmsEnabled(userId, true);
                }
            } else {
                Toast.makeText(this, "SMS notifications will be disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void navigateToInventory() {
        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        startActivity(intent);
        finish(); // Prevents returning to login screen with back button
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}